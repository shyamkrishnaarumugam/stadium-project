import React, { useState } from 'react';
import { Button, Col, Container, FloatingLabel, Form, Row } from 'react-bootstrap';
import axios from 'axios';
import { useNavigate } from 'react-router';

export default function SignUp() {
    const navigate = useNavigate();

    const signUpAlert = async (e) => {
        
        try {
            const formData = new FormData();
            formData.append('username', username);
            formData.append('email', email);
            formData.append('name', name);
            formData.append('phone', phone);
            formData.append('password', password);

            const response = await axios.post('http://localhost/stadium-backend/insert.php', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            });
            console.log(response.data); 
        } catch (error) {
            console.error(error);
        }
    };

    const [username, setUsername] = useState('');
    const [email, setEmail] = useState('');
    const [name, setName] = useState('');
    const [phone, setPhone] = useState('');
    const [password, setPassword] = useState('');

    return (
        <>
            <Container>
                <div>
                    <Row className='d-flex align-items-center min-vh-100 g-0'>
                        <Col className='mx-auto'>
                            <h1 className='text-center'>Sign Up</h1>
                            <h4 className='text-center'>(Create Your Account)</h4>

                            <Form>
                                <FloatingLabel controlId="floatingInput" label="User Name" className="mb-3">
                                    <Form.Control value={username} type="text" required onChange={(e) => setUsername(e.target.value)} />
                                </FloatingLabel>
                                <FloatingLabel controlId="floatingInput" label="Email address" className="mb-3">
                                    <Form.Control value={email} type="email" onChange={(e) => setEmail(e.target.value)} />
                                </FloatingLabel>
                                <FloatingLabel controlId="floatingInput" label="Name" className="mb-3">
                                    <Form.Control value={name} type="text" onChange={(e) => setName(e.target.value)} />
                                </FloatingLabel>
                                <FloatingLabel controlId="floatingInput" label="Phone Number" className="mb-3">
                                    <Form.Control value={phone} type="number" onChange={(e) => setPhone(e.target.value)} />
                                </FloatingLabel>
                                <FloatingLabel controlId="floatingPassword" label="Password" className="mb-3">
                                    <Form.Control value={password} type="password" onChange={(e) => setPassword(e.target.value)} />
                                </FloatingLabel>
                                <Button variant='success' type='submit' className='mt-4' onClick={signUpAlert}>Sign Up</Button><br />
                                <a href='' onClick={() => navigate('/login')}>Already have an account? Log In</a>
                            </Form>
                        </Col>
                    </Row>
                </div>
            </Container>
        </>
    );
}
